package com.online.test.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Table(name = "question")
@Entity
@Getter
@Setter
@ToString
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "question", unique = true)
	private String question;

	@Column(name = "choice1")
	private String choice1;

	@Column(name = "choice2")
	private String choice2;

	@Column(name = "choice3")
	private String choice3;

	@Column(name = "choice4")
	private String choice4;

	@Column(name = "answer", length = 1)
	private String answer;


}
