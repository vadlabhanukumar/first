package com.online.test.management.service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.online.test.management.entity.RefreshToken;
import com.online.test.management.entity.User;
import com.online.test.management.repository.RefreshTokenRepository;
import com.online.test.management.repository.UserRepository;

@Service
@Transactional
public class RefreshTokenService implements IRefreshTokenService {

	@Value("${jwt.secret.refrEshexpireMin}")
	private Long refreshTokenDurationMin;

	@Autowired
	private RefreshTokenRepository refreshTokenRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public Optional<RefreshToken> findByToken(String token) {
		return refreshTokenRepository.findByToken(token);
	}

	@Override
	public RefreshToken createRefreshToken(Long userId) {
		RefreshToken refreshToken = refreshTokenRepository.findByUserId(userId);
		if (refreshToken != null) {
			refreshToken.setUserId(userId);
			refreshToken.setExpiryDate(Instant.now().plusMillis(1000 * 60 * 60 * 24 * refreshTokenDurationMin));
			refreshToken.setToken(UUID.randomUUID().toString());
		} else {
			refreshToken = new RefreshToken();
			refreshToken.setUserId(userId);
			refreshToken.setExpiryDate(Instant.now().plusMillis(1000 * 60 * 60 * 24 * refreshTokenDurationMin));
			refreshToken.setToken(UUID.randomUUID().toString());
		}

		return refreshTokenRepository.save(refreshToken);
	}

	@Override
	public RefreshToken verifyExpiration(RefreshToken token) {

		if (token.getExpiryDate().compareTo(Instant.now()) < 0) {
			refreshTokenRepository.delete(token);
		}

		return token;
	}

	@Override
	public int deleteByUserId(Long userId) {

		User user = userRepository.findById(userId).get();
		return refreshTokenRepository.deleteByUserId(userId);
	}

}
