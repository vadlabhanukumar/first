package com.online.test.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.online.test.management.entity.Test;
import com.online.test.management.request.AddQuestionsDto;
import com.online.test.management.request.TestAddDto;
import com.online.test.management.service.TestService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/Admin")
public class AdminController {

	@Autowired
	private TestService testService;

	// test add api start

	@PostMapping("/test/v1/addTest")
	public ResponseEntity<?> addTest(@Valid @RequestBody TestAddDto test) {
		return ResponseEntity.ok(testService.saveTest(test));
	}

	@PostMapping("/test/v1/updateTest/{testId}")
	public ResponseEntity<?> updateTest(@PathVariable("testId") Long testId, @Valid @RequestBody TestAddDto test) {
		return ResponseEntity.ok(testService.updateTest(testId, test));
	}

	@GetMapping("/test/v1/fetchAllTest")
	public List<Test> fetchAllExam() {
		return testService.fetchAllExam();
	}

	@DeleteMapping(path = "/test/v1/deleteTest/{testId}")
	public ResponseEntity<?> deleteTest(@Valid @PathVariable("testId") Long testId) {
		return ResponseEntity.ok(testService.deleteTest(testId));
	}

	/// test add api end

	/// test add questionPaper in test start
	@PostMapping("/test/v1/create/addQuestions/{testId}")
	public ResponseEntity<?> addQuestions(@PathVariable("testId") Long testId,
			@Valid @RequestBody AddQuestionsDto addQuestionsDto) {
		return ResponseEntity.ok(testService.addQuestions(testId, addQuestionsDto));
	}

	@PostMapping("/test/v1/create/updateQuestions/{testId}")
	public ResponseEntity<?> updateQuestions(@PathVariable("testId") Long testId,
			@Valid @RequestBody AddQuestionsDto addQuestionsDto) {
		return ResponseEntity.ok(testService.updateQuestions(testId, addQuestionsDto));
	}

	@DeleteMapping("/test/v1/create/deleteQuestions/{testId}")
	public ResponseEntity<?> deleteQuestions(@PathVariable("testId") Long testId,
			@Valid @RequestBody AddQuestionsDto addQuestionsDto) {
		return ResponseEntity.ok(testService.deleteQuestions(testId, addQuestionsDto));
	}

	// test add questionPaper in test end

	// test test start
	@PostMapping("/test/v1/test/v1/assignTest/{testId}/{userId}")
	public ResponseEntity<?> assignTest(@PathVariable("testId") Long testId, @PathVariable("userId") Long userId)
			throws Exception {
		return ResponseEntity.ok(testService.assignTest(testId, userId));
	}

}
