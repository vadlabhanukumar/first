//package com.online.test.management.repository;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.online.test.management.entity.QuestionPaper;
//
//@Repository
//public interface PaperRepo extends JpaRepository<QuestionPaper, Long> {
//
//    @Query(value = "select * from question_paper where exam_id = ?1", nativeQuery = true)
//    List<QuestionPaper> getRandomExam(Long examId);
//}
