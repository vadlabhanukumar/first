package com.online.test.management.service;

import com.online.test.management.request.SigninRequest;
import com.online.test.management.request.SignupRequest;
import com.online.test.management.request.UpdateProfileReqDto;
import com.online.test.management.response.CommonResponse;

import jakarta.validation.Valid;

public interface AuthenticationService {
	CommonResponse signup(SignupRequest request) throws Exception;

	CommonResponse signin(SigninRequest request)  throws Exception;

	CommonResponse updateUserDetails(@Valid Long userId, UpdateProfileReqDto updateProfileReqDto) throws Exception;
}
