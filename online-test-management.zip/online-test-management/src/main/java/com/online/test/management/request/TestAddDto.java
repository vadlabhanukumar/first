package com.online.test.management.request;

import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
public class TestAddDto {

	@NotNull
	private Long testId;

	private String description;

	private double totalMarks;

	private double minMarks;
	
	private long testDuration;
	
	private long totalQuestion;
	
	private Timestamp startDate;
	
	private Timestamp endDate;

}
