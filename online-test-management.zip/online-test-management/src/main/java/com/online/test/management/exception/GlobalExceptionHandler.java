/**
 * 
 */
package com.online.test.management.exception;

import java.io.FileNotFoundException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.online.test.management.response.CommonResponse;
import com.online.test.management.util.CommonUtil;

@RestControllerAdvice
public class GlobalExceptionHandler {


//	 GlobalException
	@ExceptionHandler(Exception.class)
	public ResponseEntity<CommonResponse> ExceptionHandler(Exception se, WebRequest req) {
		MyErrorDetails err = new MyErrorDetails();
		err.setTimestamp(new Date());
		err.setMessage(se.getMessage());
		err.setDescription(req.getDescription(false));
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), se.getMessage(), err));

	}

	// ResourceNotFound Exception
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<CommonResponse> ResourceNotFoundExceptionHandler(Exception se, WebRequest req) {

		MyErrorDetails err = new MyErrorDetails();
		err.setTimestamp(new Date());
		err.setMessage(se.getMessage());
		err.setDescription(req.getDescription(false));

		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new CommonResponse(HttpStatus.NOT_FOUND.value(), se.getMessage(), err));

	}

	// ResourceNotAllowedException Exception
	@ExceptionHandler(ResourceNotAllowedException.class)
	public ResponseEntity<CommonResponse> ResourceNotAllowedExceptionHandler(Exception se, WebRequest req) {

		MyErrorDetails err = new MyErrorDetails();
		err.setTimestamp(new Date());
		err.setMessage(se.getMessage());
		err.setDescription(req.getDescription(false));
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new CommonResponse(HttpStatus.NOT_FOUND.value(), se.getMessage(), err));

	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<CommonResponse> MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e,
			WebRequest req) {
		Map<String, String> validationsErrors = new HashMap<>();

		e.getBindingResult().getAllErrors().forEach((error) -> {

			String fieldName = (((FieldError) error).getField());
			String message = error.getDefaultMessage();
			validationsErrors.put(fieldName, message);

		});

		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(new CommonResponse(HttpStatus.BAD_REQUEST.value(), CommonUtil.FAILURE, validationsErrors));

	}

	// BadCredentialsException Exception

	// FileNotFoundException Exception
	@ExceptionHandler(FileNotFoundException.class)
	public ResponseEntity<CommonResponse> FileNotFoundExceptionHandler(Exception se, WebRequest req) {

		MyErrorDetails err = new MyErrorDetails();
		err.setTimestamp(new Date());
		err.setMessage(se.getMessage());
		err.setDescription(req.getDescription(false));

		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new CommonResponse(HttpStatus.NOT_FOUND.value(), se.getMessage(), err));

	}

}
