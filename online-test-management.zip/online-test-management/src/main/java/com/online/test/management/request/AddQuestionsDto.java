package com.online.test.management.request;

import java.util.HashSet;
import java.util.Set;

import com.online.test.management.entity.Question;

import lombok.Data;

@Data
public class AddQuestionsDto {

	private Set<Question> questions = new HashSet<Question>();

}
