package com.online.test.management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.online.test.management.entity.ScoreTable;

@Repository
public interface ScoreTableRepo extends JpaRepository<ScoreTable, Integer> {

	//List<ScoreTable> findByUserId(Long userId);

	ScoreTable findByUserId(Long userId);

}
