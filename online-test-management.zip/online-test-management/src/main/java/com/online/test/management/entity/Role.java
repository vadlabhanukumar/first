package com.online.test.management.entity;

public enum Role {
    USER,
    ADMIN
}
