package com.online.test.management.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Cascade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "_test")
@Getter
@Setter
@RequiredArgsConstructor
public class Test {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long testId;

	private String description;

	private double totalMarks;
	
	private double minMarks;
	
	private long testDuration;
	
	private long totalQuestion;
	
	private Timestamp startDate;
	
	private Timestamp endDate;
	
	@OneToMany
	@Cascade(org.hibernate.annotations.CascadeType.ALL)
	@JoinColumn(name = "testId", referencedColumnName = "testId")
	private Set<Question> questions = new HashSet<Question>();
	
}
