package com.online.test.management.request;

import com.online.test.management.entity.Test;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ScoreBoardResponse {
	private Long userId;

	private String name;

	private String emailId;

	private double finalExamScore;

	private String RoundStatus;

	private Test test;

}
