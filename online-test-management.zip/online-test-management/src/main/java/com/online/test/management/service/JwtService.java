package com.online.test.management.service;

import java.util.Date;

import org.springframework.security.core.userdetails.UserDetails;

import com.online.test.management.entity.User;

public interface JwtService {
    String extractUserName(String token);

    //String generateToken(UserDetails userDetails);

    boolean isTokenValid(String token, UserDetails userDetails);

	String generateToken(UserDetails userDetails, User user);
	
	Date extractExpiration(String token);
}
