package com.online.test.management.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AnswerDto {

	@NotNull
	private Long questionId;

	@NotBlank(message = "answer is mandatory")
	private String answer;

}
