package com.online.test.management.response;

import java.util.Date;

import lombok.Data;

@Data
public class JWTResponse {
	private String token;
	private String type = "Bearer";
	private String refreshToken;
	private Date refreshTokenExpired;
	private Long userId;
	private String email;
	private Date accessTokenExpired;
	private String role;
}
