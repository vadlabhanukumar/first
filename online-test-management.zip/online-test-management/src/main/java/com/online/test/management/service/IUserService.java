package com.online.test.management.service;

import java.util.Optional;

import com.online.test.management.entity.User;

public interface IUserService {

    void saveUser(User user);
    Optional<User> findByUsername(String username);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
    User findById(int userId);
}
