package com.online.test.management.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.online.test.management.entity.RefreshToken;
import com.online.test.management.entity.User;
import com.online.test.management.enums.ErrorCodeEnum;
import com.online.test.management.repository.UserRepository;
import com.online.test.management.request.SigninRequest;
import com.online.test.management.request.SignupRequest;
import com.online.test.management.request.TokenRefreshRequest;
import com.online.test.management.response.CommonResponse;
import com.online.test.management.service.AuthenticationService;
import com.online.test.management.service.JwtService;
import com.online.test.management.service.RefreshTokenService;
import com.online.test.management.util.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {
	private final AuthenticationService authenticationService;

	private final JwtService jwtService;

	@Autowired
	RefreshTokenService refreshTokenService;

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/signup")
	public ResponseEntity<CommonResponse> signup(@RequestBody @Valid SignupRequest request) {
		CommonResponse commonResponse = null;
		try {
			commonResponse = authenticationService.signup(request);
		} catch (Exception e) {
			commonResponse = CommonUtil.errorResponse(e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonResponse);
		}
		return ResponseEntity.status(HttpStatus.OK).body(commonResponse);
	}

	@PostMapping("/signin")
	public ResponseEntity<CommonResponse> signin(@RequestBody SigninRequest request) {
		CommonResponse commonResponse = null;
		try {
			commonResponse = authenticationService.signin(request);
		} catch (Exception e) {
			commonResponse = CommonUtil.errorResponse(e);
			commonResponse = new CommonResponse(HttpStatus.BAD_REQUEST.value(), "Bad credentials!", null);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonResponse);
		}

		return ResponseEntity.status(HttpStatus.OK).body(commonResponse);
	}

	@PostMapping("/logout")
	public ResponseEntity<CommonResponse> logoutUser(@RequestParam Long userId, HttpServletRequest httpServletRequest) {

		CommonResponse commonResponse = null;
		try {
			int deletedValue = refreshTokenService.deleteByUserId(userId);

			if (deletedValue == 1) {
				commonResponse = new CommonResponse(HttpStatus.OK.value(), "Log out successful!", null);
			} else {
				commonResponse = new CommonResponse(HttpStatus.OK.value(), "You're already logout", null);
			}
		} catch (Exception e) {
			commonResponse = CommonUtil.errorResponse(e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonResponse);
		}

		return ResponseEntity.status(HttpStatus.OK).body(commonResponse);

	}

	@PostMapping("/refreshtoken")
	public ResponseEntity<CommonResponse> refreshtoken(@RequestBody TokenRefreshRequest request,
			HttpServletRequest httpServletRequest) {

		CommonResponse commonResponse = null;
		try {
			String requestRefreshToken = request.getRefreshToken();

			RefreshToken token = refreshTokenService.findByToken(requestRefreshToken)
					.orElseThrow(() -> new Exception(ErrorCodeEnum.REFRESH_TOKEN_EXISTS.getValue()));

			RefreshToken deletedToken = refreshTokenService.verifyExpiration(token);

			Long userId = deletedToken.getUserId();
			User userRefreshToken = userRepository.findByUserId(userId);

			var newTokenjwt = jwtService.generateToken(userRefreshToken, userRefreshToken);

			Map<String, Object> res = new HashMap<>();
			res.put("token", newTokenjwt);
			Date extractExpiration = jwtService.extractExpiration(newTokenjwt);
			res.put("accessTokenExpirede", extractExpiration);
			res.put("refreshTokenExpired", deletedToken.getExpiryDate());
			commonResponse = new CommonResponse(HttpStatus.OK.value(), CommonUtil.SUCCESS, res);
		} catch (Exception e) {
			commonResponse = CommonUtil.errorResponse(e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(commonResponse);
		}
		return ResponseEntity.status(HttpStatus.OK).body(commonResponse);

	}
}
