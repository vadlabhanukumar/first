package com.online.test.management.service;

import java.util.Optional;

import com.online.test.management.entity.Role;

public interface IRoleService {
	Optional<Role> findByName(Role name);
}
