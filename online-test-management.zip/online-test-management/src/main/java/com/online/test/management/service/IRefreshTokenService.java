package com.online.test.management.service;

import java.util.Optional;

import com.online.test.management.entity.RefreshToken;

public interface IRefreshTokenService {

    public Optional<RefreshToken> findByToken(String token);
    public RefreshToken verifyExpiration(RefreshToken token);
    public int deleteByUserId(Long userId);
	RefreshToken createRefreshToken(Long userId);
}
