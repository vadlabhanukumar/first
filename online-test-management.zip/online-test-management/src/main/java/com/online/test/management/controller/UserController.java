package com.online.test.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.online.test.management.repository.UserRepository;
import com.online.test.management.request.TestStartDto;
import com.online.test.management.request.UpdateProfileReqDto;
import com.online.test.management.service.AuthenticationService;
import com.online.test.management.service.TestService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/User")
public class UserController {

	@Autowired
	private TestService testService;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private  AuthenticationService authenticationService;
	// test add api start
	
	@PostMapping("/v1/getUserDetails/{userId}")
	public ResponseEntity<?> getUserDetails(@Valid @PathVariable("userId") Long userId) throws Exception {
		return ResponseEntity.ok(userRepository.findById(userId).get());
	}
	
	@PostMapping("/v1/updateUserDetails/{userId}")
	public ResponseEntity<?> updateUserDetails(@Valid @PathVariable("userId") Long userId, @RequestBody UpdateProfileReqDto updateProfileReqDto) throws Exception {
		return ResponseEntity.ok(authenticationService.updateUserDetails(userId,updateProfileReqDto));
	}
	

	@PostMapping("/test/v1/test/v1/userStartSaveTest")
	public ResponseEntity<?> userStartSaveTest(@Valid @RequestBody TestStartDto testStartDto) throws Exception {
		return ResponseEntity.ok(testService.userStartSaveTest(testStartDto));
	}

	@PostMapping("/test/v1/all/scoreBoard")
	public ResponseEntity<?> getAllScoreBoard() throws Exception {
		return ResponseEntity.ok(testService.getScoreBoard());
	}

	@GetMapping(path = "/test/v1/scoreBoard/{userId}")
	public ResponseEntity<?> getScoreBoardByCanidateId(@Valid @PathVariable("userId") Long userId) throws Exception {
		return ResponseEntity.ok(testService.getScoreBoardByCanidateId(userId));
	}

}
