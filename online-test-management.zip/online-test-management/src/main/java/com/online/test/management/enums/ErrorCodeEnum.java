package com.online.test.management.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ErrorCodeEnum {

	EXCEPTION_OCCURRED(1002, "Something went wrong, Please try after sometime !!"),
	OTHER_USER_ALREADY_EXISTS_WITH_EMAIL(1021, "Other user already exist with this Email !!"),
	REFRESH_TOKEN_EXISTS(1022, "Refresh token is not in database!"),
	INVALID_ROLE(1023, "ROLE should be user or admin!"),
	Invalide_Password(1023, "password should have at least one upper case character, one lower case character, one numeric character and one special character and the length of password should be minimum 8 characters!"),;

	@Getter
	private Integer id;

	@Getter
	private String value;

	public static ErrorCodeEnum findByValue(String value) {
		for (ErrorCodeEnum order : ErrorCodeEnum.values()) {
			if (order.getValue().equalsIgnoreCase(value)) {
				return order;
			}
		}
		return null;
	}
}