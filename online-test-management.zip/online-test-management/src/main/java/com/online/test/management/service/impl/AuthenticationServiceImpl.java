package com.online.test.management.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.online.test.management.entity.RefreshToken;
import com.online.test.management.entity.Role;
import com.online.test.management.entity.User;
import com.online.test.management.enums.ErrorCodeEnum;
import com.online.test.management.repository.UserRepository;
import com.online.test.management.request.SigninRequest;
import com.online.test.management.request.SignupRequest;
import com.online.test.management.request.UpdateProfileReqDto;
import com.online.test.management.response.CommonResponse;
import com.online.test.management.response.JWTResponse;
import com.online.test.management.service.AuthenticationService;
import com.online.test.management.service.JwtService;
import com.online.test.management.service.RefreshTokenService;
import com.online.test.management.util.CommonUtil;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtService jwtService;
	private final AuthenticationManager authenticationManager;

	@Autowired
	RefreshTokenService refreshTokenService;

	@Override
	public CommonResponse signup(SignupRequest request) throws Exception {
		if (request.getRoleName().equalsIgnoreCase(Role.USER.name())
				|| request.getRoleName().equalsIgnoreCase(Role.ADMIN.name())) {

			CommonResponse commonResponse = null;

			boolean validPassword = CommonUtil.isValidPassword(request.getPassword());
			if (validPassword == false) {
				throw new Exception(ErrorCodeEnum.Invalide_Password.getValue());
			}

			if (userRepository.existsByEmail(request.getEmail())) {
				throw new Exception(ErrorCodeEnum.OTHER_USER_ALREADY_EXISTS_WITH_EMAIL.getValue());
			}

			var user = User.builder().firstName(request.getFirstName()).lastName(request.getLastName())
					.email(request.getEmail()).password(passwordEncoder.encode(request.getPassword())).role(Role.USER)
					.build();

			if (request.getRoleName().equalsIgnoreCase(Role.USER.name())) {
				user.setRole(Role.USER);
			}
			if (request.getRoleName().equalsIgnoreCase(Role.ADMIN.name())) {
				user.setRole(Role.ADMIN);
			}
			userRepository.save(user);
			var jwt = jwtService.generateToken(user, user);
			RefreshToken refreshToken = refreshTokenService.createRefreshToken(user.getUserId());
			Date extractExpiration = jwtService.extractExpiration(jwt);
			JWTResponse jwtResponse = new JWTResponse();
			jwtResponse.setEmail(user.getEmail());
			jwtResponse.setUserId(user.getUserId());
			jwtResponse.setToken(jwt);
			jwtResponse.setAccessTokenExpired(extractExpiration);
			jwtResponse.setRefreshToken(refreshToken.getToken());
			jwtResponse.setRefreshTokenExpired(Date.from(refreshToken.getExpiryDate()));
			jwtResponse.setRole(user.getRole().toString());
			commonResponse = new CommonResponse(HttpStatus.OK.value(), CommonUtil.SUCCESS, jwtResponse);
			return commonResponse;
		}
		throw new Exception(ErrorCodeEnum.INVALID_ROLE.getValue());
	}

	@Override
	public CommonResponse signin(SigninRequest request) {
		CommonResponse commonResponse = null;
		authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
		var user = userRepository.findByEmail(request.getEmail())
				.orElseThrow(() -> new IllegalArgumentException("Invalid email or password."));
		var jwt = jwtService.generateToken(user, user);

		Date extractExpiration = jwtService.extractExpiration(jwt);
		RefreshToken refreshToken = refreshTokenService.createRefreshToken(user.getUserId());

		JWTResponse jwtResponse = new JWTResponse();
		jwtResponse.setEmail(user.getEmail());
		jwtResponse.setUserId(user.getUserId());
		jwtResponse.setToken(jwt);
		jwtResponse.setAccessTokenExpired(extractExpiration);
		jwtResponse.setRefreshToken(refreshToken.getToken());
		jwtResponse.setRefreshTokenExpired(Date.from(refreshToken.getExpiryDate()));
		jwtResponse.setRole(user.getRole().toString());

		commonResponse = new CommonResponse(HttpStatus.OK.value(), CommonUtil.SUCCESS, jwtResponse);

		return commonResponse;
	}

	@Override
	public CommonResponse updateUserDetails(@Valid Long userId, UpdateProfileReqDto updateProfileReqDto) throws Exception {

		CommonResponse commonResponse = null;

		boolean validPassword = CommonUtil.isValidPassword(updateProfileReqDto.getPassword());
		if (validPassword == false) {
			throw new Exception(ErrorCodeEnum.Invalide_Password.getValue());
		}

		if (userRepository.existsByEmail(updateProfileReqDto.getEmail())) {
			throw new Exception(ErrorCodeEnum.OTHER_USER_ALREADY_EXISTS_WITH_EMAIL.getValue());
		}
		User user = userRepository.findByUserId(userId);
		user.setEmail(updateProfileReqDto.getEmail());
		user.setFirstName(updateProfileReqDto.getFirstName());
		user.setLastName(updateProfileReqDto.getLastName());
		user.setPassword(passwordEncoder.encode(updateProfileReqDto.getPassword()));

		userRepository.save(user);
		var jwt = jwtService.generateToken(user, user);
		RefreshToken refreshToken = refreshTokenService.createRefreshToken(user.getUserId());
		Date extractExpiration = jwtService.extractExpiration(jwt);
		JWTResponse jwtResponse = new JWTResponse();
		jwtResponse.setEmail(user.getEmail());
		jwtResponse.setUserId(user.getUserId());
		jwtResponse.setToken(jwt);
		jwtResponse.setAccessTokenExpired(extractExpiration);
		jwtResponse.setRefreshToken(refreshToken.getToken());
		jwtResponse.setRefreshTokenExpired(Date.from(refreshToken.getExpiryDate()));
		jwtResponse.setRole(user.getRole().toString());
		commonResponse = new CommonResponse(HttpStatus.OK.value(), CommonUtil.SUCCESS, jwtResponse);
		return commonResponse;
	}

}
