package com.online.test.management.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.online.test.management.enums.ErrorCodeEnum;
import com.online.test.management.response.CommonResponse;

public class CommonUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);
	public static final String SUCCESS = "SUCCESS";
	public static final String SOMETHING_WENT_WRONG = "Internal Server Error";
	public static final String FAILURE = "FAILURE";

	public static void exceptionLog(Exception e) {
		LOGGER.error("Exception :  ", e);
	}

	public static Boolean isNullOrEmpty(String string) {
		return (string == null || string.isEmpty() || string.length() == 0);
	}

	public static String trim(String string) {
		if (!isNullOrEmpty(string)) {
			return string.trim();
		}
		return null;
	}

	public static CommonResponse errorResponse(Exception e) {
		ErrorCodeEnum errorCodeEnum = ErrorCodeEnum.findByValue(e.getMessage());
		if (errorCodeEnum != null) {
			return new CommonResponse(errorCodeEnum.getId(), errorCodeEnum.getValue(), null);
		} else {
			CommonUtil.exceptionLog(e);
		}
		return new CommonResponse(ErrorCodeEnum.EXCEPTION_OCCURRED.getId(), ErrorCodeEnum.EXCEPTION_OCCURRED.getValue(),
				null);
	}

	public static boolean isValidPassword(String password) {

		// Regex to check valid password.
		String regex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";

		// Compile the ReGex
		Pattern p = Pattern.compile(regex);

		// If the password is empty
		// return false
		if (password == null) {
			return false;
		}

		Matcher m = p.matcher(password);

		// Return if the password
		// matched the ReGex
		return m.matches();
	}

}