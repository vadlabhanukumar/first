package com.online.test.management.exception;

public class TestDataInvalidException extends RuntimeException
{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public  TestDataInvalidException(String message)
{
	super(message);
}
}