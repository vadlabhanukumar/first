package com.online.test.management.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.online.test.management.entity.RefreshToken;
import com.online.test.management.entity.User;

@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Integer> {

	Optional<RefreshToken> findByToken(String token);

//	@Modifying
//	int deleteByUser(User user);

	@Query("select RefreshToken from RefreshToken RefreshToken where RefreshToken.userId=:userId")
	RefreshToken findByUserId(Long userId);

	@Modifying
	@Query(value = "delete FROM from RefreshToken RefreshToken where RefreshToken.userId=:userId", nativeQuery = true)

	// @Query(value = "DELETE FROM Person WHERE city = ?1", nativeQuery = true)
	int deleteByUserId(Long userId);

}
