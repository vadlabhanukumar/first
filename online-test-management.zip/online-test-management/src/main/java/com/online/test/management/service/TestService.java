package com.online.test.management.service;

import java.util.List;

import com.online.test.management.entity.ScoreTable;
import com.online.test.management.entity.Test;
import com.online.test.management.request.AddQuestionsDto;
import com.online.test.management.request.ScoreBoardResponse;
import com.online.test.management.request.TestAddDto;
import com.online.test.management.request.TestStartDto;

import jakarta.validation.Valid;

public interface TestService {

	public Test saveTest(TestAddDto test);

	public Test updateTest(Long testId, @Valid TestAddDto test);

	public List<Test> fetchAllExam();

	public String deleteTest(Long testId);

	public Test addQuestions(Long testId, @Valid AddQuestionsDto sddQuestionsDto);

	public Test updateQuestions(Long testId, @Valid AddQuestionsDto addQuestionsDto);

	public Test deleteQuestions(Long testId, @Valid AddQuestionsDto addQuestionsDto);

	public ScoreTable assignTest(Long testId, Long userId) throws  Exception;

	ScoreBoardResponse userStartSaveTest(@Valid TestStartDto testStartDto) throws Exception;

	public List<ScoreBoardResponse> getScoreBoard() throws Exception;

	public List<ScoreBoardResponse> getScoreBoardByCanidateId(@Valid Long userId) throws Exception;

}
