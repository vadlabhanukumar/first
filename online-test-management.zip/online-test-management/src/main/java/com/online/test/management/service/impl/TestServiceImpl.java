package com.online.test.management.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.test.management.entity.Question;
import com.online.test.management.entity.ScoreTable;
import com.online.test.management.entity.Test;
import com.online.test.management.entity.User;
import com.online.test.management.exception.TestDataInvalidException;
import com.online.test.management.repository.QuestionRepo;
import com.online.test.management.repository.ScoreTableRepo;
import com.online.test.management.repository.TestRepo;
import com.online.test.management.repository.UserRepository;
import com.online.test.management.request.AddQuestionsDto;
import com.online.test.management.request.AnswerDto;
import com.online.test.management.request.ScoreBoardResponse;
import com.online.test.management.request.TestAddDto;
import com.online.test.management.request.TestStartDto;
import com.online.test.management.service.TestService;

import jakarta.validation.Valid;

@Service
public class TestServiceImpl implements TestService {

	@Autowired
	private TestRepo testRepo;

	@Autowired
	QuestionRepo questionRepo;

	@Autowired
	ScoreTableRepo scoreTableRepo;

	@Autowired
	UserRepository userRepository;

	@Override
	public Test saveTest(TestAddDto testAddDto) {
		Test test = new Test();

		Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
		int number = testAddDto.getStartDate().compareTo(timeStamp);
		if (number < 0) {
			throw new TestDataInvalidException("Start date must be greater then current date...");
		}
		int date2 = testAddDto.getStartDate().compareTo(testAddDto.getEndDate());

		if (date2 > 0)
			throw new TestDataInvalidException("End date should be greater than start date");

		Date date = new Date(testAddDto.getStartDate().getTime());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR, -5);
		cal.add(Calendar.MINUTE, -30);
		date = cal.getTime();
		Timestamp ts = new Timestamp(date.getTime());
		test.setStartDate(ts);

		date = new Date(testAddDto.getEndDate().getTime());
		cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR, -5);
		cal.add(Calendar.MINUTE, -30);
		date = cal.getTime();
		ts = new Timestamp(date.getTime());
		test.setEndDate(ts);

		test.setTotalMarks(testAddDto.getTotalMarks());
		test.setMinMarks(testAddDto.getMinMarks());
		test.setDescription(testAddDto.getDescription());
		test.setTestDuration(test.getTestDuration());

		Test save = testRepo.save(test);
		return save;
	}

	@Override
	public Test updateTest(Long testId, TestAddDto testAddDto) {
		Test test = testRepo.findByTestId(testId);

		if (test == null) {
			throw new RuntimeException("test not found");
		}
		test.setTotalMarks(testAddDto.getTotalMarks());
		test.setMinMarks(testAddDto.getMinMarks());
		test.setDescription(testAddDto.getDescription());
		Test save = testRepo.save(test);
		return save;
	}

	@Override
	public List<Test> fetchAllExam() {
		try {
			return testRepo.findAll();
		} catch (Exception e) {
			throw new RuntimeException(e.getLocalizedMessage());
		}
	}

	@Override
	public String deleteTest(Long testId) {
		try {
			testRepo.deleteById(testId);
		} catch (Exception e) {
			throw new RuntimeException(e.getLocalizedMessage());
		}
		return "deleted";
	}

	@Override
	public Test addQuestions(Long testId, @Valid AddQuestionsDto addQuestionsDto) {

		Test test = testRepo.findByTestId(testId);

		if (test == null) {
			throw new RuntimeException("test not found");
		}

		Set<Question> dbgetQuestions = test.getQuestions();
//java stream api
		List<String> collectgetQuestion = dbgetQuestions.stream().map(Question::getQuestion)
				.collect(Collectors.toList());
		if (!dbgetQuestions.isEmpty()) {
			Set<Question> questions = addQuestionsDto.getQuestions();
			for (Question question : questions) {

				if (collectgetQuestion.contains(question.getQuestion())) {

					throw new RuntimeException("question already exist");
				}
				dbgetQuestions.add(question);
			}
			test.setQuestions(dbgetQuestions);
			int size = dbgetQuestions.size();
			test.setTotalQuestion(size);
			test.setTotalMarks(size);
			Test savetest = testRepo.save(test);
			return savetest;
		} else {

			Set<Question> questions = addQuestionsDto.getQuestions();

			for (Question question : questions) {
				questions.add(question);
			}

			test.setQuestions(questions);
			int size = questions.size();
			test.setTotalQuestion(size);
			test.setTotalMarks(size);
			Test savetest = testRepo.save(test);
			return savetest;

		}

	}

	@Override
	public Test updateQuestions(Long testId, @Valid AddQuestionsDto addQuestionsDto) {
		Test test = testRepo.findByTestId(testId);

		if (test == null) {
			throw new RuntimeException("test not found");
		}

		Set<Question> dbgetQuestions = test.getQuestions();
		if (!dbgetQuestions.isEmpty()) {
			Set<Question> questions = addQuestionsDto.getQuestions();
			for (Question question : questions) {
				// Question saveQuestion = questionRepo.save(question);
				for (Question dbgetQuestion : dbgetQuestions) {

					if (dbgetQuestion.getId() == question.getId()) {
						dbgetQuestion.setAnswer(question.getAnswer());
						dbgetQuestion.setChoice1(question.getChoice1());
						dbgetQuestion.setChoice2(question.getChoice2());
						dbgetQuestion.setChoice3(question.getChoice3());
						dbgetQuestion.setChoice4(question.getChoice4());
						dbgetQuestion.setQuestion(question.getQuestion());
					}

					dbgetQuestions.add(dbgetQuestion);
				}
			}

			test.setQuestions(dbgetQuestions);
			int size = dbgetQuestions.size();
			test.setTotalQuestion(size);
			test.setTotalMarks(size);
			Test save = testRepo.save(test);
			return save;
		} else {
			throw new RuntimeException(" test is empty");

		}
	}

	@Override
	public Test deleteQuestions(Long testId, @Valid AddQuestionsDto addQuestionsDto) {
		Test test = testRepo.findByTestId(testId);

		if (test == null) {
			throw new RuntimeException("test not found");
		}

		Set<Question> dbgetQuestions = test.getQuestions();
		if (!dbgetQuestions.isEmpty()) {
			Set<Question> questions = addQuestionsDto.getQuestions();
			for (Question question : questions) {
				// Question saveQuestion = questionRepo.save(question);
				for (Question dbgetQuestion : dbgetQuestions) {

					if (dbgetQuestion.getId() == question.getId()) {
						questionRepo.delete(dbgetQuestion);
						dbgetQuestions.remove(dbgetQuestion);
						break;
					}

				}
			}
			test.setQuestions(dbgetQuestions);
			Test save = testRepo.save(test);
			return save;
		} else {
			throw new RuntimeException(" test is empty");

		}
	}

	@Override
	public ScoreTable assignTest(Long testId, Long userId) throws Exception {
		User user = userRepository.findByUserId(userId);
		if (user == null) {
			throw new Exception("user not exists");
		}
		Test test = testRepo.findByTestId(testId);

		if (test == null) {
			throw new RuntimeException("test not found");
		}
		ScoreTable scoreTable = scoreTableRepo.findByUserId(userId);
		if (scoreTable == null) {
			scoreTable = new ScoreTable();
		}
		scoreTable.setRoundStatus("pending");
		scoreTable.setUserId(userId);
		scoreTable.setTestId(testId);
		ScoreTable savescoreTable = scoreTableRepo.save(scoreTable);
		user.setScoreTable(savescoreTable);
		userRepository.save(user);
		return scoreTable;
	}

	@Override
	public ScoreBoardResponse userStartSaveTest(@Valid TestStartDto testStartDto) throws Exception {

		User user = userRepository.findByUserId(testStartDto.getUserId());
		if (user == null) {
			throw new Exception("user not exists");
		}

		Test test = testRepo.findByTestId(testStartDto.getTestId());

		if (test == null) {
			throw new RuntimeException("test not found");
		}
		ScoreTable scoreTable = user.getScoreTable();
		if (scoreTable == null) {
			scoreTable = new ScoreTable();
		}

		ScoreBoardResponse scoreBoardResponse = new ScoreBoardResponse();
		scoreTable.setTestId(testStartDto.getTestId());
		scoreTable.setUserId(testStartDto.getUserId());

		scoreTable.setRoundStatus("appeared");
		// exam start
		double marksObtain = 0.0;
		List<AnswerDto> answerDtoList = testStartDto.getAnswerDtoList();
		for (AnswerDto answerDto : answerDtoList) {
			Question dbQuestion = questionRepo.findById(answerDto.getQuestionId());
			if (dbQuestion != null) {
				if (dbQuestion.getAnswer().equalsIgnoreCase(answerDto.getAnswer())) {
					marksObtain = marksObtain + 1;
				}
			} else {
				throw new Exception("please provide valid data");
			}
		}

		scoreTable.setTestTotalMarks(marksObtain);
		ScoreTable saveScoreTable = scoreTableRepo.save(scoreTable);
		user.setScoreTable(saveScoreTable);
		userRepository.save(user);
		scoreBoardResponse.setName(user.getFirstName());
		scoreBoardResponse.setUserId(scoreTable.getUserId());
		scoreBoardResponse.setEmailId(user.getEmail());
		scoreBoardResponse.setFinalExamScore(scoreTable.getTestTotalMarks());
		scoreBoardResponse.setRoundStatus(scoreTable.getRoundStatus());
		scoreBoardResponse.setTest(test);

		return scoreBoardResponse;
	}

	@Override
	public List<ScoreBoardResponse> getScoreBoard() throws Exception {
		List<ScoreBoardResponse> scoreBoardResponseList = new ArrayList<ScoreBoardResponse>();
		List<ScoreTable> findAllScoreTable = scoreTableRepo.findAll();
		for (ScoreTable scoreTable : findAllScoreTable) {
			ScoreBoardResponse scoreBoardResponse = new ScoreBoardResponse();
			User user = userRepository.findByUserId(scoreTable.getUserId());
			if (user == null) {
				throw new Exception("user not exists");
			}

			Test test = testRepo.findByTestId(scoreTable.getTestId());

			if (test == null) {
				throw new RuntimeException("test not found");
			}

			scoreBoardResponse.setName(user.getFirstName());
			scoreBoardResponse.setUserId(scoreTable.getUserId());
			scoreBoardResponse.setEmailId(user.getEmail());

			scoreBoardResponse.setRoundStatus(scoreTable.getRoundStatus());
			scoreBoardResponse.setFinalExamScore(scoreTable.getTestTotalMarks());
			scoreBoardResponse.setTest(test);
			scoreBoardResponseList.add(scoreBoardResponse);
		}

		return scoreBoardResponseList;
	}

	@Override
	public List<ScoreBoardResponse> getScoreBoardByCanidateId(Long userId) throws Exception {
		ScoreTable scoreTable = scoreTableRepo.findByUserId(userId);
		List<ScoreBoardResponse> scoreBoardResponseList = new ArrayList<ScoreBoardResponse>();
		ScoreBoardResponse scoreBoardResponse = new ScoreBoardResponse();
		User user = userRepository.findByUserId(scoreTable.getUserId());
		if (user == null) {
			throw new Exception("user not exists");
		}
		Test test = testRepo.findByTestId(scoreTable.getTestId());

		if (test == null) {
			throw new RuntimeException("test not found");
		}
		scoreBoardResponse.setName(user.getFirstName());
		scoreBoardResponse.setUserId(scoreTable.getUserId());
		scoreBoardResponse.setEmailId(user.getEmail());

		scoreBoardResponse.setRoundStatus(scoreTable.getRoundStatus());
		scoreBoardResponse.setFinalExamScore(scoreTable.getTestTotalMarks());
		scoreBoardResponse.setTest(test);

		scoreBoardResponseList.add(scoreBoardResponse);

		return scoreBoardResponseList;
	}

}
