package com.online.test.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.online.test.management.entity.Question;

@Repository
public interface QuestionRepo extends JpaRepository<Question, Integer> {

	@Modifying
	@Query(value = "delete from question where id = ?1", nativeQuery = true)
	int deleteById(Long id);

	Question findById(Long questionId);

}
